# Enron

This page provides links to information about Enron.

## Articles

* [Wikipedia](http://en.wikipedia.org/wiki/Enron)
* [Is Enron Overpriced](http://money.cnn.com/2006/01/13/news/companies/enronoriginal_fortune/index.htm) by Bethany McLean, March 5, 2001

## Books

* [Conspiracy of Fools: A True Story](http://www.amazon.com/Conspiracy-Fools-Story-Kurt-Eichenwald/dp/0767911792/)
* [Power Failure: The Inside Story of the Collapse of Enron](http://www.amazon.com/Power-Failure-Inside-Story-Collapse/dp/076791368X/)
* [Smartest Guys in the Room: The Amazing Rise and Scandalous Fall of Enron](http://www.amazon.com/Smartest-Guys-Room-Amazing-Scandalous/dp/B000EUKRC2)

## Movies

* [Enron: The Smartest Guys in the Room (2005) DVD](http://www.amazon.com/Enron-Smartest-Guys-Room/dp/B000C3L2IO)
* [The Crooked E: The Unshredded Truth About Enron (2003) DVD](http://www.amazon.com/Crooked-Unshredded-Truth-About-Enron/dp/B000WM4R1O/)
	